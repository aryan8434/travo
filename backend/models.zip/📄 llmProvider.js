export const LLM_PROVIDER = process.env.LLM_PROVIDER || "groq";
// options: "groq" | "gemini"